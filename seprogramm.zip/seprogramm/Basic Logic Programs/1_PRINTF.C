// PROGRAM 1 : DISPLAY THE INFORMATION USING PRINTF - (START) -------------------->
#include<stdio.h>
void main(){
    printf("Vraj Thakkar");
    printf("30-1-2004");
    printf("Age is 20");
    printf("Isanpur, Ahmedabad");
}
// PROGRAM 1 : SIMPLE CALCULATOR - (END) <--------------------
