// PROGRAM 13 : FIND ASCII VALUE FROM CHARACTER - (START) -------------------->
#include<stdio.h>
void main(){
    char c;

    printf("Enter the Character : ");
    scanf("%ch", &c);

    printf("ASCII value of %ch is %d.", c, c);
}
// PROGRAM 13 : FIND ASCII VALUE FROM CHARACTER - (END) -------------------->