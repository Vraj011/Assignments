// PROGRAM 25 : FIND AVARAGE OF 5 EXPENSE - (END) -------------------->
#include <stdio.h>

main()
{
    int a1, a2, a3, a4, a5;
    float avg_expence;

    printf("eneter expance user 1 :");
    scanf("%d", &a1);

    printf("eneter expance user 2 :");
    scanf("%d", &a2);

    printf("eneter expance user 3 :");
    scanf("%d", &a3);

    printf("eneter expance user 4 :");
    scanf("%d", &a4);

    printf("eneter expance user 5 :");
    scanf("%d", &a5);

    avg_expence = (a1 + a2 + a3 + a4 + a5) / 5;

    printf("\n\navrage expance of five user is : %.2f", avg_expence);
}

// PROGRAM 25 : FIND AVARAGE OF 5 EXPENSE - (END) -------------------->