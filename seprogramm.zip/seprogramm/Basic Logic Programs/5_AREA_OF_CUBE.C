// PROGRAM 5 : FIND AREA OF CUBE - (START) -------------------->
#include<stdio.h>
void main(){
    float area, a;

    printf("Enter the side : ");
    scanf("%f", &a);

    area = 6 * a * a;  // FORMULA
    printf("Area of Cube is %.2f", area);
}
// PROGRAM 5 : FIND AREA OF CUBE - (END) <--------------------