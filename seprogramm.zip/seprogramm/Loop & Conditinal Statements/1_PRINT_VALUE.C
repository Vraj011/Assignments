// PROGRAM 1 : PRINT 972 to 897 USING FOR LOOP - (START) --------------------->
#include<stdio.h>
void main(){
    int i;

    for(i=972 ; i>=897 ; i--){
        printf("%d\n", i);
    }
}
// PROGRAM 1 : PRINT 972 to 897 USING FOR LOOP - (END) --------------------->