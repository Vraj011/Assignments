var mongoose = require('mongoose');
// mongoose.connect('mongodb://localhost:27017/Vraj', { useNewUrlParser: true, useUnifiedTopology: true });
mongoose.connect('mongodb+srv://vrajthakkar:vrajk@cluster0.agmfu.mongodb.net/Vraj', { useNewUrlParser: true, useUnifiedTopology: true });
const express=require('express');
const app=express();
app.use(express.json());

const cors = require('cors');
app.use(cors());
app.use(cors({
  origin: 'http://localhost:3000'  // Allow requests from React app
}));

// Schema means table coumn validation
const userSchema= mongoose.Schema({
    id:Number,
    name:String,
    email:String,
	password:String,
	mobile:String,
    img:String
});

const categorySchema= mongoose.Schema({
    id:Number,
    cate_name:String,
    cate_img:String
});

const productSchema= mongoose.Schema({
    id:Number,
    Product_Title:String,
    Product_description:String,
	Product_price:String,
    Product_img:String
});

// create model/table appy validation on table coumn
const userModel=mongoose.model("user",userSchema);
const categoryModel=mongoose.model("category",categorySchema);
const productModel=mongoose.model("product",productSchema);



// insert data by schema
app.post("/insertuser", async (req, resp) => {
    let data = new userModel(req.body)
    const result=await data.save();
    resp.send(result);
})

app.post("/insertcategory", async (req, resp) => {
    let data = new categoryModel(req.body)
    const result=await data.save();
    resp.send(result);
})
app.post("/insertproduct", async (req, resp) => {
    let data = new productModel(req.body)
    const result=await data.save();
    resp.send(result);
})

// get all data
app.get("/get", async (req, resp) => {
    let data = await userModel.find();
    resp.send(data);
})
app.get("/getcategory", async (req, resp) => {
    let data = await categoryModel.find();
    resp.send(data);
})
app.get("/getproduct", async (req, resp) => {
    let data = await productModel.find();
    resp.send(data);
})

// get Single data by column

app.get("/single", async (req, resp) => {
    let data = await userModel.find({name:"raj nagar"});
    resp.send(data);
})

//put http://localhost:5000/update/637f3ba97f546bbfeae336c3

app.put("/update/:_id",async (req, resp) => {
    console.log(req.params)
    let data = await userModel.updateOne(
        req.params,
        {$set: req.body}
    );
    resp.send(data);
})

//delete  http://localhost:5000/delete/637f3ba97f546bbfeae336c3
app.delete("/delete", async (req, resp) => {
    let data = await userModel.deleteOne(req.body);
    resp.send(data);
})
app.delete("/deletecategory", async (req, resp) => {
    let data = await categoryModel.deleteOne(req.body);
    resp.send(data);
})
app.delete("/deleteproduct", async (req, resp) => {
    let data = await productModel.deleteOne(req.body);
    resp.send(data);
})


app.listen(5000);