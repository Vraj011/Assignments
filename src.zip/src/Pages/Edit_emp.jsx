import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
import { useNavigate ,useParams} from 'react-router-dom';

function Edit_emp() {
    useEffect(() => {
        editdata();
    }, []);

    const [formvalue,setFormvalue]=useState({
        id:"",
        name:"",
        email:"",
        password:"",
        mobile:"",
        img:""
    })

    const {id}=useParams();
    const editdata = async () => {
        const res = await axios.get(`http://localhost:3000/employee/${id}`);
        //console.log(res.data);
        setFormvalue({...formvalue,id:res.data.id,name:res.data.name,
            email:res.data.email,password:res.data.password,mobile:res.data.mobile,img:res.data.img});
    }


  

    const changehandel=(e)=>{
        setFormvalue({...formvalue,[e.target.name]:e.target.value});
        console.log(formvalue);
    }


    const validation=()=>{
        let result=true;
        if(formvalue.name=="" || formvalue.name==null)
        {
            toast.error('Name field is required !');
            result=false;
        }
        
        if(formvalue.email=="" || formvalue.email==null)
        {
            toast.error('email field is required !');
            result=false;
        }
        else if(!formvalue.email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/))
        {
            toast.error('Enter valid email field !');
            result=false;
        }

        if(formvalue.password=="" || formvalue.password==null)
        {
            toast.error('password field is required !');
            result=false;
        }
        if(formvalue.mobile=="" || formvalue.mobile==null)
        {
            toast.error('mobile field is required !');
            result=false;
        }
        if(formvalue.img=="" || formvalue.img==null)
        {
            toast.error('img field is required !');
            result=false;
        }

        return result;
    }

    const redirect=useNavigate();
    const submithandel=async(e)=>{
        
        e.preventDefault();// not refresh page on submit
        if(validation())
        {
            const res=await axios.patch(`http://localhost:3000/employee/${formvalue.id}`,formvalue);
            if(res.status==200)
            {
                toast.success('Update Success !');
                setFormvalue({...formvalue,name:"",email:"",password:"",mobile:"",img:""});
                return redirect('/manage_emp');     
            }   
        }
    }
  return (
    <div>
         <div className="container-fluid col-md-8">
                <div className="container-fluid">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title fw-semibold mb-4">Edit employee</h5>
                            <div className="card">
                                <div className="card-body">
                                <form>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Name </label>
                                            <input value={formvalue.name} onChange={changehandel} name='name' type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                                            <input value={formvalue.email} onChange={changehandel} name='email' type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                                            <input value={formvalue.password} onChange={changehandel} name='password' type="password" className="form-control" id="exampleInputPassword1" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Mobile</label>
                                            <input  value={formvalue.mobile} onChange={changehandel} name='mobile' type="number" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>                                        
                                        <div>                                   
                                            <div className="mb-3 mt-4">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Image link</label>
                                            <input value={formvalue.img} onChange={changehandel} name='img' type="url" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>
                                        </div>

                                        <button type="submit" onClick={submithandel} className="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>



    </div>
  )
}

export default Edit_emp