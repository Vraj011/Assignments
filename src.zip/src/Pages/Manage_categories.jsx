import React, { useState, useEffect } from 'react'
import axios from 'axios';
import {toast} from 'react-toastify';
import {redirect, useNavigate} from 'react-router-dom'

function Manage_categories() {

    useEffect(() => {
        fetch();
    }, []);
    const redirect=useNavigate();
    const [data, Setdata] = useState([]);

    const fetch = async () => {
        const res = await axios.get('http://localhost:3000/categories');
        Setdata(res.data);
    }
    const deletedata = async (id) => {
        const res = await axios.delete(`http://localhost:3000/categories/${id}`);
        toast.success('Categorie delete success');
        fetch();
    }
    return (
        <div>
            <div id="page-wrapper">
                <div id="page-inner">
                    <div className="container-fluid col-md-7">
                        <div className="col-md-12">
                            <h1 className="page-head-line">Manage Categories</h1>

                        </div>
                    </div>
                    {/* /. ROW  */}
                    <div className="container-fluid col-md-8">
                        <div className="col-md-12   ">
                            {/*   Kitchen Sink */}
                            <div className="panel panel-default">
                               
                                <div className="panel-body">
                                    <div className="table-responsive">
                                        <table className="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Name</th>
                                                    <th>Image</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    data.map((value,index,entarr) => {
                                                        return (
                                                            <tr>
                                                                <td>{value.id}</td>
                                                                <td>{value.cate_name}</td>
                                                                <td><img src={value.cate_img} width="100px" alt="" /></td>
                                                                <td>
                                                                    <button className='btn btn-info'onClick={ ()=>{ redirect('/edit_categories/'+ value.id) }}>Edit</button>
                                                                    <button onClick={()=>{deletedata(value.id);}} className='btn btn-danger'>Delete</button>
                                                                </td>

                                                            </tr>
                                                        )
                                                    })
                                                }


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            {/* End  Kitchen Sink */}
                        </div>

                    </div>
                </div>
            </div>
        </div>

    )
}

export default Manage_categories