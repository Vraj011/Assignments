import React, { useState } from 'react'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';
function Login() {
  
  const redirect=useNavigate();

  const [formvalue, setFormvalue] = useState({
      email: "",
      password: "",
  });

  const changeHandel = (e) => {
    setFormvalue({ ...formvalue, [e.target.name]: e.target.value });
    console.log(formvalue);
}

const vadidation = () => {
    var result = true;

    if (formvalue.email == "") {
        toast.error('email Field is required !')
        result = false;
    }
    if (formvalue.password == "") {
        toast.error('password Field is required !')
        result = false;
    }

    return result;
}

const submitHandel = async (e) => {
    e.preventDefault();
    if (vadidation()) {

        const res=await axios.get(`http://localhost:3000/admin?email=${formvalue.email}`);
        if(res.data.length>0)
        {
            if(res.data[0].password==formvalue.password)
            {

                localStorage.setItem('admin_id',res.data[0].id);
                localStorage.setItem('admin_name',res.data[0].name);
                toast.success('Login Success');
                setFormvalue({ ...formvalue,email: "", password: ""});
                return redirect('/index');
            }
            else
            {
                toast.error('Invalid Password');
                setFormvalue({ ...formvalue,email: "", password: ""});
                return false;
            }
        }
        else
        {
            toast.error('Invalid Username');
            setFormvalue({ ...formvalue,email: "", password: ""});
            return false;
        }
    }
}


  return (
<div>
  <section className="vh-100">
    <div className="container py-5 h-100">
      <div className="row d-flex align-items-center justify-content-center h-100">
        <div className="col-md-8 col-lg-7 col-xl-6">
          <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg" className="img-fluid" alt="Phone image" />
        </div>
        <div className="col-md-7 col-lg-5 col-xl-5 offset-xl-1">
          <form>
            {/* Email input */}
            <div className="form-outline mb-4">
              <label className="form-label" htmlFor="form1Example13">Email address</label>
              <input type="email"  name="email" value={formvalue.email} onChange={changeHandel} id="form1Example13" className="form-control form-control-lg" />
            </div>
            {/* Password input */}
            <div className="form-outline mb-4">
              <label className="form-label" htmlFor="form1Example23">Password</label>
              <input type="password"name="password" value={formvalue.password} onChange={changeHandel} id="form1Example23" className="form-control form-control-lg" />
            </div>
            {/* Submit button */}
            <button type="submit" onClick={submitHandel} className="btn btn-primary btn-lg btn-block">Sign in</button>
            <div className="divider d-flex align-items-center my-4">
              
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>

  )
}

export default Login