import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
import { useNavigate ,useParams} from 'react-router-dom';

function Edit_contact() {
    useEffect(() => {
        editdata();
    }, []);

    const [formvalue,setFormvalue]=useState({
        id:"",
        name:"",
        email:"",
        mobile:""
    });
    const {id}=useParams();
    const editdata = async () => {
        const res = await axios.get(`http://localhost:3000/contact/${id}`);
        //console.log(res.data);
        setFormvalue({...formvalue,id:res.data.id,name:res.data.name,
            email:res.data.email,mobile:res.data.mobile});
    }

    const changehandel=(e)=>{

        setFormvalue({...formvalue,id:new Date().getTime().toString(),created_at:new Date(),updated_at:new Date(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    // const submithandel=async(e)=>{
    //     e.preventDefault();
    //     const res=await axios.post(`http://localhost:3000/contact`,formvalue);
    //     console.log(res);
    //     if(res.status==201)
    //     {
    //         toast.success('Contact Add success !');
    //         setFormvalue({...formvalue,name:"",email:"",mobile:""});
    //     }
    // }
    const validation=()=>{
        let result=true;
        if(formvalue.name=="" || formvalue.name==null)
        {
            toast.error('Name field is required !');
            result=false;
        }
        
        if(formvalue.email=="" || formvalue.email==null)
        {
            toast.error('email field is required !');
            result=false;
        }
        else if(!formvalue.email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/))
        {
            toast.error('Enter valid email field !');
            result=false;
        }

        
        if(formvalue.mobile=="" || formvalue.mobile==null)
        {
            toast.error('mobile field is required !');
            result=false;
        }
        

        return result;
    }
    const redirect=useNavigate();
    const submithandel=async(e)=>{
        
        e.preventDefault();// not refresh page on submit
        if(validation())
        {
            const res=await axios.patch(`http://localhost:3000/contact/${formvalue.id}`,formvalue);
            if(res.status==200)
            {
                toast.success('Update Success !');
                setFormvalue({...formvalue,name:"",email:"",mobile:""});
                return redirect('/manage_contact');     
            }   
        }
    }
    return (
        <div>
            <div id="page-wrapper">
                <div id="page-inner">
                    <div className="container-fluid col-md-4">
                        <div className="col-md-12">
                            <h1 className="page-head-line">Add Contact</h1>
                        </div>
                    </div>
                    {/* /. ROW  */}
                    <div className="container-fluid col-md-7">
                        <div className="col-md-12 col-sm-12 col-xs-12">
                            <div className="panel panel-primary">
                                

                                <div className="panel-body">
                                    <form action="" method="post">
                                        <div className="form-group">
                                            <label>Name</label>
                                            <input value={formvalue.name} onChange={changehandel} className="form-control" name="name" type="text" />
                                            
                                        </div>
                                        <div className="form-group">
                                            <label>Email</label>
                                            <input value={formvalue.email} onChange={changehandel} className="form-control" name="email" type="email" />
                                            
                                        </div>
                                        <div className="form-group">
                                            <label>mobile</label>
                                            <input value={formvalue.mobile} onChange={changehandel} className="form-control" name="mobile" type="number" />
                                            
                                        </div>

                                        <button type="submit" onClick={submithandel} className="btn btn-info">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                {/* /. PAGE INNER  */}
            </div>
        </div>

    )
}

export default Edit_contact