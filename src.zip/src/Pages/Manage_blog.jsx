import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { toast } from 'react-toastify';
import {useNavigate} from 'react-router-dom'

function Manage_blog() {
    useEffect(() => {
        fetch();
    }, []);

    const [data, Setdata] = useState([]);
    const redirect=useNavigate();
    const fetch = async () => {
        const res = await axios.get('http://localhost:3000/blog');
        //console.log(res.data);
        Setdata(res.data);
    }

    const deletedata = async (id) => {
        const res = await axios.delete(`http://localhost:3000/blog/${id}`);
        toast.success('Blog delete success');
        fetch();
    }

    return (
        <div>
            <div id="page-wrapper">
                <div id="page-inner">
                    <div className="container-fluid col-md-7">
                        <div className="col-md-12">
                            <h1 className="page-head-line">Manage Blog</h1>

                        </div>
                    </div>
                    {/* /. ROW  */}
                    <div className="container-fluid col-md-8">
                        <div className="col-md-12   ">
                            {/*   Kitchen Sink */}
                            <div className="panel panel-default">
                                <div className="panel-heading">
                                    Manage Blog
                                </div>
                                <div className="panel-body">
                                    <div className="table-responsive">
                                        <table className="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#ID</th>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <th>Image</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    data.map((value, index, entarr) => {
                                                        return (
                                                            <tr>
                                                                <td>{value.id}</td>
                                                                <td>{value.title}</td>
                                                                <td>{value.desc}</td>
                                                                <td><img src={value.img} width="100px" alt="" /></td>
                                                                <td>
                                                                    <button className='btn btn-info' onClick={ ()=>{ redirect('/edit_blog/'+ value.id) }}>Edit</button>
                                                                    <button onClick={() => { deletedata(value.id); }} className='btn btn-danger'>Delete</button>
                                                                </td>

                                                            </tr>
                                                        )
                                                    })
                                                }

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                    </div>

                    
                </div>
                
            </div>
        </div>

    )
}

export default Manage_blog