import React, { useState, useEffect } from 'react'
import axios from 'axios';
import {toast} from 'react-toastify';
import {useNavigate} from 'react-router-dom'

function Manage_contact() {

    useEffect(() => {
        fetch();
    }, []);
    const redirect=useNavigate();
    const [data, Setdata] = useState([]);

    const fetch = async () => {
        const res = await axios.get('http://localhost:3000/contact');
        //console.log(res.data);
        Setdata(res.data);
    }

    const deletedata = async (id) => {
        const res = await axios.delete(`http://localhost:3000/contact/${id}`);
        toast.success('Contact delete success');
        fetch();
    }
    return (
        <div>
            <div id="page-wrapper">
                <div id="page-inner">
                    <div className="container-fluid col-md-7">
                        <div className="col-md-12">
                            <h1 className="page-head-line">Manage Contact</h1>
                           
                        </div>
                    </div>
                    {/* /. ROW  */}
                    <div className="container-fluid col-md-8">
                        <div className="col-md-12   ">
                            {/*   Kitchen Sink */}
                            <div className="panel panel-default">
                                
                                <div className="panel-body">
                                    <div className="table-responsive">
                                        <table className="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#ID</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Mobile</th>
                                                    {/* <th>Action</th> */}
                                                </tr>
                                            </thead>
                                            <tbody>
                                            {
                                                    data.map((value,index,entarr) => {
                                                        return (
                                                            <tr>
                                                                <td>{value.id}</td>
                                                                <td>{value.name}</td>
                                                                <td>{value.email}</td>
                                                                <td>{value.mobile}</td>
                                                                {/* <td>{value.comment}</td> */}
                                                                <td>
                                                                    <button className='btn btn-info' onClick={ ()=>{ redirect('/edit_contact/'+ value.id) }}>Edit</button>
                                                                    <button onClick={()=>{deletedata(value.id);}} className='btn btn-danger'>Delete</button>
                                                                </td>

                                                            </tr>
                                                        )
                                                    })
                                                }
                                              
                                              
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            {/* End  Kitchen Sink */}
                        </div>
                        
                    </div>
                   
                    {/* /. ROW  */}
                </div>
                {/* /. PAGE INNER  */}
            </div>
        </div>

    )
}

export default Manage_contact