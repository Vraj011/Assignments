
import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
function Add_categories() {
   
    const [formvalue,setFormvalue]=useState({
        id:"",
        cate_name:"",
        cate_img:"",
        created_at:"",
        updated_at:""
    });

    const changehandel=(e)=>{

        setFormvalue({...formvalue,id:new Date().getTime().toString(),created_at:new Date(),updated_at:new Date(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    const submithandel=async(e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/categories`,formvalue);
        console.log(res);
        if(res.status==201)
        {
            toast.success('Categories Add success !');
            setFormvalue({...formvalue,cate_name:"",cate_img:""});
        }
    }
  return (
    <div> <div className="container-fluid col-md-8">
    <div className="container-fluid">
        <div className="card">
            <div className="card-body">
                <h1 className="card-title fw-semibold mb-4">Add categories</h1>
                <div className="card">
                    <div className="card-body">
                        <form>
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">cate_name</label>
                                <input value={formvalue.cate_name} onChange={changehandel} type="text" className="form-control" id="exampleInputEmail1" name="cate_name" aria-describedby="emailHelp" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="exampleInputPassword1" className="form-label">cate_img</label>
                                <input type="url" value={formvalue.cate_img} onChange={changehandel} className="form-control" name="cate_img" id="exampleInputPassword1" />
                            </div>
                            
                            <button type="submit" onClick={submithandel} className="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

</div>
  )
}

export default Add_categories