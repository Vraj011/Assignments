import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';

function Add_user() {
    const [formvalue,setFormvalue]=useState({
        id:"",
        name:"",
        email:"",
        password:"",
        mobile:"",
        status:"",
        img:""
        
    });

    const changehandel=(e)=>{

        setFormvalue({...formvalue,id:new Date().getTime().toString(),created_at:new Date(),updated_at:new Date(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    const submithandel=async(e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/user`,formvalue);
        console.log(res);
        if(res.status==201)
        {
            toast.success('User Add success !');
            setFormvalue({...formvalue,name:"",email:"",password:"",mobile:"", img:""});
        }
    }
    return (
        
        <div>
            <div className="container-fluid col-md-8">
                <div className="container-fluid">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title fw-semibold mb-4">Forms</h5>
                            <div className="card">
                                <div className="card-body">
                                    <form>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Name </label>
                                            <input value={formvalue.name} onChange={changehandel} name='name' type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                                            <input value={formvalue.email} onChange={changehandel} name='email' type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                                            <input value={formvalue.password} onChange={changehandel} name='password' type="password" className="form-control" id="exampleInputPassword1" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Mobile</label>
                                            <input  value={formvalue.mobile} onChange={changehandel} name='mobile' type="number" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">gender</label>
                                        
                                        <div>
                                            <div className="form-check">
                                                <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
                                                <label className="form-check-label" htmlFor="flexRadioDefault1">
                                                    Male
                                                </label>
                                            </div>
                                            <div className="form-check">
                                                <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" defaultChecked />
                                                <label className="form-check-label" htmlFor="flexRadioDefault2">
                                                    Female
                                                </label>
                                            </div>
                                            </div>
                                            <div className="mb-3 mt-4">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Image link</label>
                                            <input value={formvalue.img} onChange={changehandel} name='img' type="url" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                        </div>
                                        </div>

                                        <button type="submit" onClick={submithandel} className="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


        </div>
    )
}

export default Add_user