import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
import { useNavigate ,useParams} from 'react-router-dom';

function Edit_blog() {
    const [formvalue,setFormvalue]=useState({
        id:"",
        title:"",
        img:"",
        desc:""
    });

    const changehandel=(e)=>{

        setFormvalue({...formvalue,id:new Date().getTime().toString(),created_at:new Date(),updated_at:new Date(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    const submithandel=async(e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/blog`,formvalue);
        console.log(res);
        if(res.status==201)
        {
            toast.success('Blog Add success !');
            setFormvalue({...formvalue,title:"",desc:"",img:""});
        }
    }
    return (
        <div>
            <div id="page-wrapper">
                <div id="page-inner">
                    <div className="container-fluid col-md-4">
                        <div className="col-md-12">
                            <h1 className="page-head-line">Edit Blog</h1>
                        </div>
                    </div>
                    {/* /. ROW  */}
                    <div className="container-fluid col-md-7">
                        <div className="col-md-12 col-sm-12 col-xs-12">
                            <div className="panel panel-primary">
                               
                                
                                <div className="panel-body">
                                        <div className="form-group">
                                            <label>Title</label>
                                            <input value={formvalue.title} onChange={changehandel} name="title" className="form-control" type="text" />
                                            
                                        </div>
										 <div className="form-group">
                                            <label>desc</label>
                                            <input value={formvalue.desc} onChange={changehandel}name="desc" className="form-control" type="email" />
                                        </div>
										
										<div className="form-group">
                                            <label>Upload Image</label>
                                            <input value={formvalue.img} onChange={changehandel}name="img" className="form-control" type="url" />
                                            
                                        </div>
                                   
                                    
                                    <button type="submit" onClick={submithandel} className="btn btn-info">Submit</button>
                                </div>
                            </div>
                        </div>
                      
                    </div>
                </div>
                {/* /. PAGE INNER  */}
            </div>
        </div>

    )
}

export default Edit_blog