import { BrowserRouter,Routes,Route } from "react-router-dom";
import React,{lazy,Suspense} from "react";

import Header from "./Component/Header";
import Index from "./Pages/Index";
import Add_emp from "./Pages/Add_emp";
// import Manage_emp from "./Pages/Manage_emp";
import Add_categories from "./Pages/Add_categories";
import Manage_categories from "./Pages/Manage_categories";
import Add_user from "./Pages/Add_user";
import Manage_user from "./Pages/Manage_user";
import Manage_blog from "./Pages/Manage_blog";
import Add_blog from "./Pages/Add_blog";
import Add_contact from "./Pages/Add_contact";
import Manage_contact from "./Pages/Manage_contact";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Login from "./Pages/Login";
import Edit_emp from "./Pages/Edit_emp";
import Edit_categories from "./Pages/Edit_categories";
import Edit_blog from "./Pages/Edit_blog";
import Edit_contact from "./Pages/Edit_contact";
import Add_product from "./Pages/Add_product";
import Manage_product from "./Pages/Manage_product";
import Edit_product from "./Pages/Edit_product";


const Manage_emp=React.lazy(()=> import('./Pages/Manage_emp'));

function App() {
  return (
    <BrowserRouter>
    <ToastContainer></ToastContainer>
    <Routes>
      {(()=>{
        if(localStorage.getItem('admin_id'))
      {
        return(
        <>
      <Route path="/"  element={<><Login/></>}></Route>      
      <Route path="/index"  element={<><Header/><Index/></>}></Route>
      <Route path="/add_emp" element={<><Header/><Add_emp/></>}></Route>
      <Route path="/manage_emp" element={<><Header/> <Suspense fallback = { <div className="spinner-border" />} ><Manage_emp/></Suspense></>}></Route>
      <Route path="/edit_emp/:id" element={<><Header/><Edit_emp/></>}></Route>
      <Route path="/add_categories" element={<><Header/><Add_categories/></>}></Route>
      <Route path="/manage_categories" element={<><Header/><Manage_categories/></>}></Route>
      <Route path="/edit_categories/:id" element={<><Header/><Edit_categories/></>}></Route>  
      <Route path="/add_product" element={<><Header/><Add_product/></>}></Route>
      <Route path="/manage_product" element={<><Header/><Manage_product/></>}></Route>
      <Route path="/edit_product/:id" element={<><Header/><Edit_product/></>}></Route>  
      <Route path="/add_user" element={<><Header/><Add_user/></>}></Route>
      <Route path="/manage_user" element={<><Header/><Manage_user/></>}></Route>
      <Route path="/add_blog" element={<><Header/><Add_blog/></>}></Route>
      <Route path="/manage_blog" element={<><Header/><Manage_blog/></>}></Route>
      <Route path="/edit_blog/:id" element={<><Header/><Edit_blog/></>}></Route> 
      <Route path="/add_contact" element={<><Header/><Add_contact/></>}></Route>
      <Route path="/manage_contact" element={<><Header/><Manage_contact/></>}></Route>
      <Route path="/edit_contact/:id" element={<><Header/><Edit_contact/></>}></Route> 
    
    </>
    )
  }
  else
  {
    return(
    <>  
      <Route path="/"  element={<><Login/></>}></Route>   
       </>
  )}
  })()}
  </Routes>
    </BrowserRouter>
  );
}

export default App;
