import React,{useEffect} from 'react'
import { NavLink, Link, useNavigate } from 'react-router-dom'

import { toast } from 'react-toastify'
function Header() {

    const redirect= useNavigate();
    useEffect(()=>{
        if(!localStorage.getItem('admin_id'))
        {
            return redirect('/');
        }
    },[]);
    
    const logout = () => {

        localStorage.removeItem('admin_id');
        localStorage.removeItem('admin_name');
        toast.success('Logout Success');
        return redirect('/');
    }
    return (
        <div>
              {/* Sidebar Start */}
              <aside className="left-sidebar col-md-4">
                    {/* Sidebar scroll*/}
                    <div>
                        <div className="brand-logo d-flex align-items-center justify-content-between">
                            <a href="./index.html" className="text-nowrap logo-img">
                                <img src="../assets/images/logos/dark-logo.svg" width={180} alt />
                            </a>
                            <div className="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                                <i className="ti ti-x fs-8" />
                            </div>
                        </div>
                        {/* Sidebar navigation*/}
                        <nav className="sidebar-nav scroll-sidebar" data-simplebar>
                       
                                
                            <ul id="sidebarnav">
            
                                <li className="nav-small-cap">
                                    <i className="ti ti-dots nav-small-cap-icon fs-4" />
                                    <span className="hide-menu">Home</span>
                                </li>
                                <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/index" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-layout-dashboard" />
                                        </span>
                                        <span className="hide-menu">Dashboard</span>
                                    </Link>
                                </li>
                                <li className="nav-small-cap">
                                    <i className="ti ti-dots nav-small-cap-icon fs-4" />
                                    <span className="hide-menu"> COMPONENTS</span>
                                </li>
                                
                                <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/manage_emp" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-article" />
                                        </span>
                                        <span className="hide-menu">Manage Employee</span>
                                    </Link>
                                </li>
                                <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/add_emp" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-article" />
                                        </span>
                                        <span className="hide-menu">Add Employee</span>
                                    </Link>
                                </li>
                                <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/add_categories" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Add Categories</span>
                                    </Link>
                                </li>
                                <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/manage_categories" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Manage Categories</span>
                                    </Link>
                                    </li>
                                    <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/add_product" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Add product</span>
                                    </Link>
                                </li>
                                <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/manage_product" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Manage product</span>
                                    </Link>
                                    </li>
                                    <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/add_user" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Add User</span>
                                    </Link>
                                    </li>
                                    <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/manage_user" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Manage User</span>
                                    </Link>
                                    </li>
                                    <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/add_blog" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Add Blog</span>
                                    </Link>
                                    </li>
                                    <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/manage_blog" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Manage Blog</span>
                                    </Link>
                                    </li>
                                    <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/add_contact" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Add Contact</span>
                                    </Link>
                                    </li>
                                    <li className="sidebar-item">
                                    <Link className="sidebar-link" to="/manage_contact" aria-expanded="false">
                                        <span>
                                            <i className="ti ti-cards" />
                                        </span>
                                        <span className="hide-menu">Manage Contact</span>
                                    </Link>
                                    </li>
                                                                               
                            </ul>
                        </nav>
                        {/* End Sidebar navigation */}
                    </div>
                    {/* End Sidebar scroll*/}
                </aside>
            <div className="body-wrapper">
                {/*  Header Start */}
                <header className="app-header">
                    <nav className="navbar navbar-expand-lg navbar-light">
                        <ul className="navbar-nav">
                            <li className="nav-item d-block d-xl-none">
                                <a className="nav-link sidebartoggler nav-icon-hover" id="headerCollapse" href="javascript:void(0)">
                                    <i className="ti ti-menu-2" />
                                </a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link nav-icon-hover" href="javascript:void(0)">
                                    <i className="ti ti-bell-ringing" />
                                    <div className="notification bg-primary rounded-circle" />
                                </a>
                            </li>
                        </ul>
                        <div className="navbar-collapse justify-content-end px-0" id="navbarNav">
                            <ul className="navbar-nav flex-row ms-auto align-items-center justify-content-end">
                                <Link to="https://adminmart.com/product/modernize-free-bootstrap-admin-dashboard/" target="_blank" className="btn btn-primary">Download Free</Link>
                                <li className="nav-item dropdown">
                                    <Link className="nav-link nav-icon-hover" to="javascript:void(0)" id="drop2" data-bs-toggle="dropdown" aria-expanded="false">
                                        <img src="../assets/images/profile/user-1.jpg" alt width={35} height={35} className="rounded-circle" />
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop2">
                                        <div className="message-body">
                                            <Link to="javascript:void(0)" className="d-flex align-items-center gap-2 dropdown-item">
                                                <i className="ti ti-user fs-6" />
                                                <p className="mb-0 fs-3">My Profile</p>
                                            </Link>
                                            <Link to="javascript:void(0)" className="d-flex align-items-center gap-2 dropdown-item">
                                                <i className="ti ti-mail fs-6" />
                                                <p className="mb-0 fs-3">My Account</p>
                                            </Link>
                                            <Link to="javascript:void(0)" className="d-flex align-items-center gap-2 dropdown-item">
                                                <i className="ti ti-list-check fs-6" />
                                                <p className="mb-0 fs-3">My Task</p>
                                            </Link>
                                            <Link to="./authentication-login.html" className="btn btn-outline-primary mx-3 mt-2 d-block">Logout</Link>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </header>
                {/*  Header End */}</div>
        </div>

    )
}

export default Header